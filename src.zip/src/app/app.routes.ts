import { Routes } from '@angular/router';
import { TaskComponent } from './task/task.component';
import { HomeComponent } from './home/home.component';
import { AlbumComponent } from './album/album.component';
import { FormComponent } from './form/form.component';


export const routes: Routes = [
    {path: 'home', component: HomeComponent},
    {path: 'task', component: TaskComponent},
    {path: 'news', component: AlbumComponent}, 
    { path: 'form', component: FormComponent },  
    {path: '', redirectTo: '/home', pathMatch: 'full'}
];
